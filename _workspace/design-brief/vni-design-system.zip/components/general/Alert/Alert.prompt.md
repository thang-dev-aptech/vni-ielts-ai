Alert from @vni/ui. Use via `window.VniUi.Alert` (bundle loaded from the root `_ds_bundle.js`).

An inline message.

<b>`error` means something has broken.</b> It is not for "time is running
out" or "you have not written enough yet" — `DESIGN.md` law L1 reserves red
for failure, and using it for ordinary progress trains people to ignore it.
Use `warning` for informational urgency.

`role="alert"` only on error and warning: an assertive announcement
interrupts whatever a screen-reader user was reading, which is right for a
failure and rude for a confirmation.

## Props

```ts
interface AlertProps {
/** `error` means something has broken. It is NOT for "time is running out" or "you have not written enough yet" — DESIGN.md law L1 reserves red for failure. Use `warning` for informational urgency. `error` and `warning` announce assertively via role="alert"; `info` and `success` use role="status". */
tone: 'info' | 'success' | 'warning' | 'error';
/** Optional bold first line above the body. */
title?: string;
children: React.ReactNode;
}
```
