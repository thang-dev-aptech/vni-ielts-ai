import * as React from 'react';

/**
 * Alert — from @vni/ui@0.0.0.
 */
export interface AlertProps {
/** `error` means something has broken. It is NOT for "time is running out" or "you have not written enough yet" — DESIGN.md law L1 reserves red for failure. Use `warning` for informational urgency. `error` and `warning` announce assertively via role="alert"; `info` and `success` use role="status". */
tone: 'info' | 'success' | 'warning' | 'error';
/** Optional bold first line above the body. */
title?: string;
children: React.ReactNode;
}

export declare const Alert: React.ComponentType<AlertProps>;
