import * as React from 'react';

/**
 * Field — from @vni/ui@0.0.0.
 */
export interface FieldProps {
/** A real `<label>` bound by id — never a placeholder standing in for one. */
label: string;
/** Shown under the field, wired through `aria-describedby`, and marks the input `aria-invalid`. */
error?: string;
/** Helper text under the field, also announced via `aria-describedby`. */
hint?: string;
name?: string;
type?: string;
value?: string;
defaultValue?: string;
placeholder?: string;
required?: boolean;
disabled?: boolean;
autoComplete?: string;
onChange?: React.ChangeEventHandler<HTMLInputElement>;
className?: string;
style?: React.CSSProperties;
}

export declare const Field: React.ComponentType<FieldProps>;
