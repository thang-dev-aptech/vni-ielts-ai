Field from @vni/ui. Use via `window.VniUi.Field` (bundle loaded from the root `_ds_bundle.js`).

A labelled input.

The label is a real `<label>` bound by id, not a placeholder. A placeholder
disappears the moment someone types, which leaves anyone who paused — or who
is using a screen reader — with no idea what the field was for.

`aria-invalid` and `aria-describedby` are wired so an error is announced
rather than only shown in red. `DESIGN.md` requires state to survive the
greyscale test; colour alone is never the signal.

## Props

```ts
interface FieldProps {
/** A real `<label>` bound by id — never a placeholder standing in for one. */
label: string;
/** Shown under the field, wired through `aria-describedby`, and marks the input `aria-invalid`. */
error?: string;
/** Helper text under the field, also announced via `aria-describedby`. */
hint?: string;
name?: string;
type?: string;
value?: string;
defaultValue?: string;
placeholder?: string;
required?: boolean;
disabled?: boolean;
autoComplete?: string;
onChange?: React.ChangeEventHandler<HTMLInputElement>;
className?: string;
style?: React.CSSProperties;
}
```
