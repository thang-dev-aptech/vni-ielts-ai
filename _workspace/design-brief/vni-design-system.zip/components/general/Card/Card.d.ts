import * as React from 'react';

/**
 * Card — from @vni/ui@0.0.0.
 */
export interface CardProps {
/** Renders the recessed layer (`--sunk` background, `--line-2` border, `--r-md` radius) instead of the raised one. Depth in this system comes from three background layers plus a hairline border — there is no shadow token and none should be added. */
sunk?: boolean;
style?: React.CSSProperties;
children: React.ReactNode;
}

export declare const Card: React.ComponentType<CardProps>;
