// Re-export of @vni/ui@0.0.0 Card. Implementation is in the root _ds_bundle.js (window.VniUi).
Object.assign(window, { Card: window.VniUi.Card });
