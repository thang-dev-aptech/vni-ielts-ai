Card from @vni/ui. Use via `window.VniUi.Card` (bundle loaded from the root `_ds_bundle.js`).

Depth comes from three background layers plus a hairline border.
There is no shadow token in this system and none should be added —
`DESIGN.md` direction C dropped them deliberately.

## Props

```ts
interface CardProps {
/** Renders the recessed layer (`--sunk` background, `--line-2` border, `--r-md` radius) instead of the raised one. Depth in this system comes from three background layers plus a hairline border — there is no shadow token and none should be added. */
sunk?: boolean;
style?: React.CSSProperties;
children: React.ReactNode;
}
```
