Spinner from @vni/ui. Use via `window.VniUi.Spinner` (bundle loaded from the root `_ds_bundle.js`).

Loading, empty and error states.

These are first-class components rather than inline `{loading && ...}`
because <b>this is where exam software actually breaks</b>. The screen
inventory's definition of done names them explicitly, and the previous
attempt at this product listed them as the one part worth keeping.

## Props

```ts
interface SpinnerProps {
/** Required. Announced via role="status" / aria-live="polite", so it must say what is loading rather than just "Loading". */
label: string;
}
```
