import * as React from 'react';

/**
 * Spinner — from @vni/ui@0.0.0.
 */
export interface SpinnerProps {
/** Required. Announced via role="status" / aria-live="polite", so it must say what is loading rather than just "Loading". */
label: string;
}

export declare const Spinner: React.ComponentType<SpinnerProps>;
