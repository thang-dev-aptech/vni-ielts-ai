import * as React from 'react';

/**
 * Button — from @vni/ui@0.0.0.
 */
export interface ButtonProps {
/** Only one `primary` per viewport — DESIGN.md states it as a rule, not a preference. Secondary actions are `secondary` (outlined) or `quiet`. `danger` is reserved for something that has broken or is about to be destroyed, never for ordinary emphasis. */
variant?: 'primary' | 'secondary' | 'quiet' | 'danger';
/** Renders `busyLabel` and disables the button. Separate from `disabled` on purpose: a busy button and an unavailable button mean different things to someone reading the screen. */
busy?: boolean;
/** Label shown while `busy` is true. */
busyLabel?: string;
fullWidth?: boolean;
disabled?: boolean;
type?: 'button' | 'submit' | 'reset';
onClick?: React.MouseEventHandler<HTMLButtonElement>;
'aria-label'?: string;
className?: string;
style?: React.CSSProperties;
children: React.ReactNode;
}

export declare const Button: React.ComponentType<ButtonProps>;
