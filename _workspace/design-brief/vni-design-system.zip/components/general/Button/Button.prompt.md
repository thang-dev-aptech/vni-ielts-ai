Button from @vni/ui. Use via `window.VniUi.Button` (bundle loaded from the root `_ds_bundle.js`).

One primary action per view.

`DESIGN.md` states it as a rule rather than a preference: never two solid
accent buttons in the same viewport. Secondary actions are outlined or
quiet. Inside an exam the primary action is always submit — nothing may
compete with it.

## Props

```ts
interface ButtonProps {
/** Only one `primary` per viewport — DESIGN.md states it as a rule, not a preference. Secondary actions are `secondary` (outlined) or `quiet`. `danger` is reserved for something that has broken or is about to be destroyed, never for ordinary emphasis. */
variant?: 'primary' | 'secondary' | 'quiet' | 'danger';
/** Renders `busyLabel` and disables the button. Separate from `disabled` on purpose: a busy button and an unavailable button mean different things to someone reading the screen. */
busy?: boolean;
/** Label shown while `busy` is true. */
busyLabel?: string;
fullWidth?: boolean;
disabled?: boolean;
type?: 'button' | 'submit' | 'reset';
onClick?: React.MouseEventHandler<HTMLButtonElement>;
'aria-label'?: string;
className?: string;
style?: React.CSSProperties;
children: React.ReactNode;
}
```
