// Re-export of @vni/ui@0.0.0 Button. Implementation is in the root _ds_bundle.js (window.VniUi).
Object.assign(window, { Button: window.VniUi.Button });
