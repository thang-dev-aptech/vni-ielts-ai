// Re-export of @vni/ui@0.0.0 EmptyState. Implementation is in the root _ds_bundle.js (window.VniUi).
Object.assign(window, { EmptyState: window.VniUi.EmptyState });
