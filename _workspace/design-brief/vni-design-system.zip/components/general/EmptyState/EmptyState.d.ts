import * as React from 'react';

/**
 * EmptyState — from @vni/ui@0.0.0.
 */
export interface EmptyStateProps {
title: string;
/** Say why it is empty. An empty state that offers a dead button is worse than one that admits the feature is not built. */
description: string;
/** Optional call to action — typically a `<Button>`. */
action?: React.ReactNode;
}

export declare const EmptyState: React.ComponentType<EmptyStateProps>;
