EmptyState from @vni/ui. Use via `window.VniUi.EmptyState` (bundle loaded from the root `_ds_bundle.js`).

Nothing here yet — and it says why, rather than showing a blank panel.

An empty state that offers a dead button is worse than one that admits the
feature is not built.

## Props

```ts
interface EmptyStateProps {
title: string;
/** Say why it is empty. An empty state that offers a dead button is worse than one that admits the feature is not built. */
description: string;
/** Optional call to action — typically a `<Button>`. */
action?: React.ReactNode;
}
```
