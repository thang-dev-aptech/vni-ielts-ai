PageHeader from @vni/ui. Use via `window.VniUi.PageHeader` (bundle loaded from the root `_ds_bundle.js`).

## Props

```ts
interface PageHeaderProps {
/** Rendered as the page `<h1>`. */
title: string;
/** Muted line under the title. */
subtitle?: string;
}
```
