// Re-export of @vni/ui@0.0.0 PageHeader. Implementation is in the root _ds_bundle.js (window.VniUi).
Object.assign(window, { PageHeader: window.VniUi.PageHeader });
