import * as React from 'react';

/**
 * PageHeader — from @vni/ui@0.0.0.
 */
export interface PageHeaderProps {
/** Rendered as the page `<h1>`. */
title: string;
/** Muted line under the title. */
subtitle?: string;
}

export declare const PageHeader: React.ComponentType<PageHeaderProps>;
