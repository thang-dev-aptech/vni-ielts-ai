ErrorState from @vni/ui. Use via `window.VniUi.ErrorState` (bundle loaded from the root `_ds_bundle.js`).

## Props

```ts
interface ErrorStateProps {
title: string;
description: string;
/** Optional recovery action — typically a `<Button>`. Announced via role="alert". */
action?: React.ReactNode;
}
```
