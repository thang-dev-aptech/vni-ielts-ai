import * as React from 'react';

/**
 * ErrorState — from @vni/ui@0.0.0.
 */
export interface ErrorStateProps {
title: string;
description: string;
/** Optional recovery action — typically a `<Button>`. Announced via role="alert". */
action?: React.ReactNode;
}

export declare const ErrorState: React.ComponentType<ErrorStateProps>;
