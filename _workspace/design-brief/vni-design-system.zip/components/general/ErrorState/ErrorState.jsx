// Re-export of @vni/ui@0.0.0 ErrorState. Implementation is in the root _ds_bundle.js (window.VniUi).
Object.assign(window, { ErrorState: window.VniUi.ErrorState });
