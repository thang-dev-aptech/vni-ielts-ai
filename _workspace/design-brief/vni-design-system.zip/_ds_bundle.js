/* @ds-bundle: {"namespace":"VniUi","components":[{"name":"Alert","sourcePath":"components/general/Alert/Alert.jsx"},{"name":"Button","sourcePath":"components/general/Button/Button.jsx"},{"name":"Card","sourcePath":"components/general/Card/Card.jsx"},{"name":"EmptyState","sourcePath":"components/general/EmptyState/EmptyState.jsx"},{"name":"ErrorState","sourcePath":"components/general/ErrorState/ErrorState.jsx"},{"name":"Field","sourcePath":"components/general/Field/Field.jsx"},{"name":"PageHeader","sourcePath":"components/general/PageHeader/PageHeader.jsx"},{"name":"Spinner","sourcePath":"components/general/Spinner/Spinner.jsx"}],"sourceHashes":{"components/general/Alert/Alert.jsx":"b5408b940b74","components/general/Alert/Alert.d.ts":"1bc3e00a1c7c","components/general/Alert/Alert.prompt.md":"100f1abebb32","components/general/Button/Button.jsx":"d8672b9606f0","components/general/Button/Button.d.ts":"95bc215b2aad","components/general/Button/Button.prompt.md":"c6680fb69256","components/general/Card/Card.jsx":"35057b5bfd23","components/general/Card/Card.d.ts":"add616e9baa7","components/general/Card/Card.prompt.md":"3ed23a965f27","components/general/EmptyState/EmptyState.jsx":"1b82d78cd3d0","components/general/EmptyState/EmptyState.d.ts":"e4f3ae957725","components/general/EmptyState/EmptyState.prompt.md":"010f8c007cd9","components/general/ErrorState/ErrorState.jsx":"5420e291ceee","components/general/ErrorState/ErrorState.d.ts":"ceece147e59d","components/general/ErrorState/ErrorState.prompt.md":"5b8c9fea57d7","components/general/Field/Field.jsx":"7788e722fea2","components/general/Field/Field.d.ts":"1cb9e61a2a97","components/general/Field/Field.prompt.md":"eeb627da914b","components/general/PageHeader/PageHeader.jsx":"95b341e661ae","components/general/PageHeader/PageHeader.d.ts":"8e48cdc62fa6","components/general/PageHeader/PageHeader.prompt.md":"e08c880676a0","components/general/Spinner/Spinner.jsx":"c7235feb7bde","components/general/Spinner/Spinner.d.ts":"61bbea83cef0","components/general/Spinner/Spinner.prompt.md":"54892e31fa64"},"inlinedExternals":[],"builtBy":"cc-design-sync"} */
"use strict";
var VniUi = (() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __esm = (fn, res, err) => function __init() {
    if (err) throw err[0];
    try {
      return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
    } catch (e) {
      throw err = [e], e;
    }
  };
  var __commonJS = (cb, mod) => function __require() {
    try {
      return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
    } catch (e) {
      throw mod = 0, e;
    }
  };
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

  // <define:import.meta.env>
  var init_define_import_meta_env = __esm({
    "<define:import.meta.env>"() {
    }
  });

  // shim:react-shim
  var require_react_shim = __commonJS({
    "shim:react-shim"(exports, module) {
      init_define_import_meta_env();
      var R = window.React;
      function np(p, k) {
        var o = {};
        for (var x in p) if (x !== "children") o[x] = p[x];
        if (k !== void 0) o.key = k;
        return o;
      }
      function jsx6(t, p, k) {
        var c = p && p.children;
        return c === void 0 ? R.createElement(t, np(p, k)) : R.createElement(t, np(p, k), c);
      }
      function jsxs5(t, p, k) {
        return R.createElement.apply(R, [t, np(p, k)].concat(p.children));
      }
      module.exports = R;
      module.exports.jsx = jsx6;
      module.exports.jsxs = jsxs5;
      module.exports.jsxDEV = function(t, p, k, s) {
        return (s ? jsxs5 : jsx6)(t, p, k);
      };
      module.exports.Fragment = R.Fragment;
    }
  });

  // packages/ui/src/index.ts
  var src_exports = {};
  __export(src_exports, {
    Alert: () => Alert,
    Button: () => Button,
    Card: () => Card,
    EmptyState: () => EmptyState,
    ErrorState: () => ErrorState,
    Field: () => Field,
    PageHeader: () => PageHeader,
    Spinner: () => Spinner
  });
  init_define_import_meta_env();

  // packages/ui/src/Button.tsx
  init_define_import_meta_env();
  var import_jsx_runtime = __toESM(require_react_shim(), 1);
  function Button({
    variant = "primary",
    busy = false,
    busyLabel,
    fullWidth = false,
    disabled,
    children,
    style,
    ...rest
  }) {
    const palette = {
      // D-10: the primary action is --primary (#06803a, 5.05:1 on white text),
      // not --acc. --acc is for links, informational text and the Reading chip,
      // which is why `quiet` keeps it — a quiet button reads as a link.
      primary: {
        background: "var(--primary)",
        color: "#fff",
        borderColor: "var(--primary)",
        boxShadow: "var(--shadow-press-primary)"
      },
      secondary: { background: "var(--card)", color: "var(--ink)", borderColor: "var(--line)" },
      quiet: { background: "transparent", color: "var(--acc)", borderColor: "transparent" },
      // --bad is reserved for something that has actually broken or is about to
      // be destroyed. It is never used for ordinary emphasis.
      danger: {
        background: "var(--bad)",
        color: "#fff",
        borderColor: "var(--bad)",
        boxShadow: "var(--shadow-press-danger)"
      }
    };
    const isDisabled = disabled === true || busy;
    return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
      "button",
      {
        ...rest,
        disabled: isDisabled,
        "aria-busy": busy,
        style: {
          ...palette[variant],
          width: fullWidth ? "100%" : void 0,
          padding: "var(--s-3) var(--s-5)",
          fontSize: "var(--t-16)",
          fontWeight: 600,
          lineHeight: "var(--lh-body)",
          border: "var(--bw-2) solid",
          borderRadius: "var(--r-md)",
          cursor: isDisabled ? "not-allowed" : "pointer",
          opacity: isDisabled ? 0.6 : 1,
          transition: `background var(--dur) var(--ease), opacity var(--dur) var(--ease)`,
          ...style
        },
        children: busy && busyLabel ? busyLabel : children
      }
    );
  }

  // packages/ui/src/Field.tsx
  init_define_import_meta_env();
  var import_react = __toESM(require_react_shim(), 1);
  var import_jsx_runtime2 = __toESM(require_react_shim(), 1);
  function Field({ label, error, hint, style, ...rest }) {
    const id = (0, import_react.useId)();
    const errorId = `${id}-error`;
    const hintId = `${id}-hint`;
    const describedBy = [error ? errorId : null, hint ? hintId : null].filter(Boolean).join(" ");
    return /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("div", { style: { marginBottom: "var(--s-4)" }, children: [
      /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("label", { htmlFor: id, className: "label", style: { display: "block" }, children: label }),
      /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(
        "input",
        {
          ...rest,
          id,
          "aria-invalid": error !== void 0,
          "aria-describedby": describedBy === "" ? void 0 : describedBy,
          style: {
            display: "block",
            width: "100%",
            marginTop: "var(--s-2)",
            padding: "var(--s-3)",
            fontSize: "var(--t-16)",
            lineHeight: "var(--lh-body)",
            color: "var(--ink)",
            background: "var(--card)",
            border: `1px solid ${error !== void 0 ? "var(--bad)" : "var(--line)"}`,
            borderRadius: "var(--r-sm)",
            ...style
          }
        }
      ),
      hint !== void 0 && /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(
        "p",
        {
          id: hintId,
          style: { marginTop: "var(--s-2)", fontSize: "var(--t-14)", color: "var(--muted)" },
          children: hint
        }
      ),
      error !== void 0 && /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(
        "p",
        {
          id: errorId,
          style: { marginTop: "var(--s-2)", fontSize: "var(--t-14)", color: "var(--bad)" },
          children: error
        }
      )
    ] });
  }

  // packages/ui/src/Alert.tsx
  init_define_import_meta_env();
  var import_jsx_runtime3 = __toESM(require_react_shim(), 1);
  function Alert({
    tone,
    title,
    children
  }) {
    const palette = {
      info: { fg: "var(--acc-700)", bg: "var(--acc-soft)" },
      success: { fg: "var(--ok)", bg: "var(--ok-soft)" },
      warning: { fg: "var(--warn)", bg: "var(--warn-soft)" },
      error: { fg: "var(--bad)", bg: "var(--bad-soft)" }
    };
    const { fg, bg } = palette[tone];
    const assertive = tone === "error" || tone === "warning";
    return /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)(
      "div",
      {
        role: assertive ? "alert" : "status",
        style: {
          padding: "var(--s-3) var(--s-4)",
          marginBottom: "var(--s-4)",
          background: bg,
          color: fg,
          border: `1px solid ${fg}`,
          borderRadius: "var(--r-sm)",
          fontSize: "var(--t-14)",
          lineHeight: "var(--lh-body)"
        },
        children: [
          title !== void 0 && /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("strong", { style: { display: "block", marginBottom: "var(--s-1)" }, children: title }),
          children
        ]
      }
    );
  }

  // packages/ui/src/Card.tsx
  init_define_import_meta_env();
  var import_jsx_runtime4 = __toESM(require_react_shim(), 1);
  function Card({
    children,
    sunk = false,
    style
  }) {
    return /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(
      "div",
      {
        style: {
          background: sunk ? "var(--sunk)" : "var(--card)",
          border: `1px solid ${sunk ? "var(--line-2)" : "var(--line)"}`,
          borderRadius: sunk ? "var(--r-md)" : "var(--r-lg)",
          padding: "var(--pad-card)",
          ...style
        },
        children
      }
    );
  }
  function PageHeader({ title, subtitle }) {
    return /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("header", { style: { marginBottom: "var(--s-6)" }, children: [
      /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("h1", { children: title }),
      subtitle !== void 0 && /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("p", { style: { marginTop: "var(--s-2)", color: "var(--muted)" }, children: subtitle })
    ] });
  }

  // packages/ui/src/States.tsx
  init_define_import_meta_env();
  var import_jsx_runtime5 = __toESM(require_react_shim(), 1);
  function Spinner({ label }) {
    return /* @__PURE__ */ (0, import_jsx_runtime5.jsxs)(
      "div",
      {
        role: "status",
        "aria-live": "polite",
        style: {
          display: "flex",
          alignItems: "center",
          gap: "var(--s-3)",
          padding: "var(--s-5)",
          color: "var(--muted)"
        },
        children: [
          /* @__PURE__ */ (0, import_jsx_runtime5.jsx)(
            "span",
            {
              "aria-hidden": "true",
              style: {
                width: 16,
                height: 16,
                border: "2px solid var(--line)",
                borderTopColor: "var(--acc)",
                borderRadius: "50%",
                // prefers-reduced-motion zeroes --dur, which would freeze this. A
                // fixed duration keeps the indicator honest for everyone; the
                // reduced-motion concern is large moving surfaces, not a 16px dot.
                animation: "vni-spin 700ms linear infinite"
              }
            }
          ),
          /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("span", { children: label }),
          /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("style", { children: `@keyframes vni-spin { to { transform: rotate(360deg) } }` })
        ]
      }
    );
  }
  function EmptyState({
    title,
    description,
    action
  }) {
    return /* @__PURE__ */ (0, import_jsx_runtime5.jsxs)(
      "div",
      {
        style: {
          padding: "var(--s-7) var(--s-5)",
          textAlign: "center",
          background: "var(--sunk)",
          border: "1px dashed var(--line)",
          borderRadius: "var(--r-md)"
        },
        children: [
          /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("p", { style: { color: "var(--ink)", fontWeight: 600 }, children: title }),
          /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("p", { style: { marginTop: "var(--s-2)", color: "var(--muted)", fontSize: "var(--t-14)" }, children: description }),
          action !== void 0 && /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("div", { style: { marginTop: "var(--s-4)" }, children: action })
        ]
      }
    );
  }
  function ErrorState({
    title,
    description,
    action
  }) {
    return /* @__PURE__ */ (0, import_jsx_runtime5.jsxs)(
      "div",
      {
        role: "alert",
        style: {
          padding: "var(--s-6) var(--s-5)",
          textAlign: "center",
          background: "var(--bad-soft)",
          border: "1px solid var(--bad)",
          borderRadius: "var(--r-md)"
        },
        children: [
          /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("p", { style: { color: "var(--bad)", fontWeight: 600 }, children: title }),
          /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("p", { style: { marginTop: "var(--s-2)", color: "var(--ink-2)", fontSize: "var(--t-14)" }, children: description }),
          action !== void 0 && /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("div", { style: { marginTop: "var(--s-4)" }, children: action })
        ]
      }
    );
  }
  return __toCommonJS(src_exports);
})();
window.VniUi=VniUi.__dsMainNs?Object.assign({},VniUi,VniUi.__dsMainNs,{__dsMainNs:undefined}):VniUi;
